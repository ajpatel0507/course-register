    <footer class="page-footer pt-0">
      <div class="text-center p-2" style="background-color: rgba(0, 0, 0, 0.2);">
        <p>Copyright © 2021 COWIN. All Rights Reserved</p>
      </div>
    </footer>
  </body>
</html>
